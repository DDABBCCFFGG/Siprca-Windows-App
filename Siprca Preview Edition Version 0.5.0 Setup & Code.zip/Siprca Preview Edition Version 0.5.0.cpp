﻿#include <iostream>
#include<math.h>
using namespace std;
string ope;
struct tools
{
	void input()
	{
		cout << "Please enter the tool code (see README.txt for details):";
		cin >> ope;
		return;
	}
	void baseconversion()
	{
		cout << "Please Enter the current base, the number of operations to be performed, and the target base.";
		int n,m,dnum,tmp;
		string a,ans;
		cin >> n >> a >> m;
		for(int i = 0;i < a.size();i++)
		{
			if(a[i] >= '0' && a[i] <= '9')
			{
				dnum = dnum * n + (a[i] - '0');
			}
			else
			{
				dnum = dnum * n + (a[i] - 'A' + 10);
			}
		}
		while(dnum > 0)
		{
			tmp = dnum % m;
			dnum /= m;
			if(tmp < 10)
			{
				ans += tmp + '0';
			}
			tmp = 0;
		}
		reverse(ans.begin(),ans.end());
		cout << ans;
		return;
	}
	void calculator()
	{
		double x,y,ans{};
		char calope;
		while(true)
		{
			cout << "Please enter an equation (See README.txt for more details):";
			cin >> x >> calope >> y;
			if(calope == '+')
			{
				ans = x + y;
				break;
			}
			if(calope == '-')
			{
				ans = x - y;
				break;
			}
			if(calope == '*')
			{
				ans = x * y;
				break;
			}
			if(calope == '/')
			{
				ans = x / y;
				break;
			}
			if(calope == '^')
			{
				ans = pow(x,y);
				break;
			}
		}
		printf("%lf %c %lf = %lf",x,calope,y,ans);
		

	}
	void tool_if()
	{
		if(ope == "CAL")
		{
			calculator();
		}
		if(ope == "BCO")
		{
			//baseconversion();
			cout << "It was repairing.";
			tool_if();
		}
	}
}tool_box;
int main()
{
	tool_box.input();
	tool_box.tool_if();
	return 0;
}